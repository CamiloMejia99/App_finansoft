﻿$(document).ready(function () {
    $("#guardar").click(function () {
        $("#theForm").submit();
    });
})